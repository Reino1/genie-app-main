# genie-app
Application client et institution financière 
